---
name: Compilation issue
about: Report a problem when compiling the code
title: ''
labels: 'compilation'
assignees: ''

---

#### Describe your question

...

#### Check all that apply (change to `[x]`)
- [ ] Windows
- [ ] macOS
- [ ] Linux
