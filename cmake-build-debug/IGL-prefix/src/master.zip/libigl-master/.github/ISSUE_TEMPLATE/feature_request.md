---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

#### Describe your feature request

...

#### Check all that apply (change to `[x]`)
- [ ] Windows
- [ ] macOS
- [ ] Linux
